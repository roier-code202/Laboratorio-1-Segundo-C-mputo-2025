<?php
include 'includes/conexion.php';
include 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];

    // Consulta SQL para actualizar el producto
    $sql = "UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio=$precio, stock=$stock WHERE id=$id";

    // Ejecutar la consulta y verificar si fue exitosa
    if ($conexion->query($sql) === TRUE) {
        header("Location: index.php"); // Redirigir a la página principal
        exit(); // Asegurarse de que el script se detenga después de la redirección
    } else {
        echo "Error: " . $conexion->error; // Mostrar error si la consulta falla
    }
}

// Obtener el ID del producto a editar desde la URL
$id = $_GET['id'];

// Consulta SQL para obtener los datos del producto
$sql = "SELECT * FROM productos WHERE id=$id";
$resultado = $conexion->query($sql);

// Verificar si se encontró el producto
if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
} else {
    echo "Producto no encontrado.";
    exit();
}
?>

<h2>Editar Producto</h2>
<form method="POST">
    <input type="hidden" name="id" value="<?php echo $fila['id']; ?>">
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" value="<?php echo $fila['nombre']; ?>" required><br>

    <label for="descripcion">Descripción:</label>
    <textarea name="descripcion"><?php echo $fila['descripcion']; ?></textarea><br>

    <label for="precio">Precio:</label>
    <input type="number" step="0.01" name="precio" value="<?php echo $fila['precio']; ?>" required><br>

    <label for="stock">Stock:</label>
    <input type="number" name="stock" value="<?php echo $fila['stock']; ?>" required><br>

    <button type="submit">Actualizar</button>
</form>

<?php include 'includes/footer.php'; ?>