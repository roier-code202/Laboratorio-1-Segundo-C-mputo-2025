<?php
// Incluir archivos necesarios
include 'includes/conexion.php';  // Conexión a la base de datos
include 'includes/header.php';    // Header común

// Consulta para obtener todos los productos
$sql = "SELECT * FROM productos";
$resultado = $conexion->query($sql);

if (!$resultado) {
    die("Error en la consulta: " . $conexion->error);
}
?>

<h2>Lista de Productos</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($fila = $resultado->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $fila['id']; ?></td>
                <td><?php echo $fila['nombre']; ?></td>
                <td><?php echo $fila['descripcion']; ?></td>
                <td><?php echo $fila['precio']; ?></td>
                <td><?php echo $fila['stock']; ?></td>
                <td>
                    <a href="editar.php?id=<?php echo $fila['id']; ?>">Editar</a>
                    <a href="eliminar.php?id=<?php echo $fila['id']; ?>">Eliminar</a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<?php include 'includes/footer.php'; ?>