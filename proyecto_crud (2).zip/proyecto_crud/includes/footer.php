<?php
echo '<footer>';
echo '<p>&copy; ' . date("Y") . ' - CRUD con PHP y MariaDB</p>';
echo '</footer>';
?>
