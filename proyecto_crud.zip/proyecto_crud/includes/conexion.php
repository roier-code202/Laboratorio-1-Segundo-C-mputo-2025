<?php
// conexion.php
$servidor = "localhost";
$usuario = "root";  // Usuario de la base de datos
$password = "";     // Contraseña de la base de datos
$base_datos = "crud";  // Nombre de la base de datos

// Crear conexión
$conexion = new mysqli($servidor, $usuario, $password, $base_datos);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>